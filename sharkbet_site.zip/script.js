
function playGame() {
    alert('Divirta-se jogando no SHARKBET!');
}
